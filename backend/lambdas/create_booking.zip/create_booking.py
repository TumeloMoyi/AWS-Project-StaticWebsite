import json
import boto3
import uuid
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('BaiaBookings')

def lambda_handler(event, context):
    try:
        # Parse the incoming request
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event.get('body', {})
        
        # Create booking record
        booking = {
            'bookingId': str(uuid.uuid4()),
            'fullName': body.get('fullName', ''),
            'email': body.get('email', ''),
            'phone': body.get('phone', ''),
            'bookingDate': body.get('bookingDate', ''),
            'bookingTime': body.get('bookingTime', ''),
            'partySize': int(body.get('partySize', 0)),
            'specialRequests': body.get('specialRequests', ''),
            'status': 'confirmed',
            'createdAt': datetime.now().isoformat()
        }
        
        # Save to DynamoDB
        table.put_item(Item=booking)
        
        # Return success response
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'success': True,
                'message': 'Booking confirmed!',
                'bookingId': booking['bookingId']
            })
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'success': False,
                'message': str(e)
            })
        }Get-Content create_booking.py | Measure-Object -Line